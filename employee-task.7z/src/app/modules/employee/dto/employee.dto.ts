export interface EmployeeDto {
  id?: number;
  name?: string;
  salary?: number;
  date_of_joning?: string;
  age?: number;
}
